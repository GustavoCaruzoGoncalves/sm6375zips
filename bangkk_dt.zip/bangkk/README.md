# Device configuration files for Motorola moto g84 5G (bangkk)
